//
//  CppFramework.h
//  CppFramework
//
//  Created by Nezar Ali on 15/10/2024.
//

#import <Foundation/Foundation.h>
#import <CppFramework/C++_Header.h>

//! Project version number for CppFramework.
FOUNDATION_EXPORT double CppFrameworkVersionNumber;

//! Project version string for CppFramework.
FOUNDATION_EXPORT const unsigned char CppFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CppFramework/PublicHeader.h>
