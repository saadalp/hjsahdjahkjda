#import <Foundation/Foundation.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>


@interface Core : NSObject

- (NSString *)deobfuscate:(long long)id :(NSString *)value;

- (void)InitializeModel;

@end
