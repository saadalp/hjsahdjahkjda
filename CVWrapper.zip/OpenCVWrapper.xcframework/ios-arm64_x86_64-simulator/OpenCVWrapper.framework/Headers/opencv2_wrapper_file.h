#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SharpnessResult : NSObject

@property (nonatomic, assign) BOOL isSharp;
@property (nonatomic, assign) double variance;
@property (nonatomic, assign) double mean;

- (instancetype)initWithSharpness:(BOOL)isSharp
                         variance:(double)variance
                             mean:(double)mean;

@end

@interface OpenCVHelper : NSObject

+ (SharpnessResult *)isImageSharp:(NSData *)pixelData
                            width:(NSInteger)width
                           height:(NSInteger)height
                        threshold:(double)threshold;

@end

NS_ASSUME_NONNULL_END
