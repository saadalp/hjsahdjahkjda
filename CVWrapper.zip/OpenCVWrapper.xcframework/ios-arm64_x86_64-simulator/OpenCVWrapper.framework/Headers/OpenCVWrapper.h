//
//  OpenCVWrapper.h
//  OpenCVWrapper
//
//  Created by Saad Albasha on 02/12/2024.
//

#import <Foundation/Foundation.h>

//! Project version number for OpenCVWrapper.
FOUNDATION_EXPORT double OpenCVWrapperVersionNumber;

//! Project version string for OpenCVWrapper.
FOUNDATION_EXPORT const unsigned char OpenCVWrapperVersionString[];

