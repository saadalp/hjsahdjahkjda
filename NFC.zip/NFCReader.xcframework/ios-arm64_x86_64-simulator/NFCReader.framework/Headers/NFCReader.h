//
//  NFCReader.h
//  NFCReader
//
//  Created by Nezar Ali on 13/02/2025.
//

#import <Foundation/Foundation.h>

//! Project version number for NFCReader.
FOUNDATION_EXPORT double NFCReaderVersionNumber;

//! Project version string for NFCReader.
FOUNDATION_EXPORT const unsigned char NFCReaderVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NFCReader/PublicHeader.h>


